
$(document).ready(function(){

    $('#menu-toggle').click(function(){

        $('#mobile-menu').stop(true,true).slideToggle(300);

        $(this).toggleClass('active');

    });

});



$(window).on('load', function(){

    setTimeout(function(){

        $('.page-loader').addClass('hide');

    }, 900);

});



